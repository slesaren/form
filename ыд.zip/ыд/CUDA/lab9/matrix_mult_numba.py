# CUDA (Numba)

import numpy as np
import time
from numba import cuda

@cuda.jit
def matrix_mul(A, B, C):
    row, col = cuda.grid(2)
    if row < C.shape[0] and col < C.shape[1]:
        sum_value = 0
        for k in range(A.shape[1]):
            sum_value += A[row, k] * B[k, col]
        C[row, col] = sum_value

# Размер матриц
N = 512
A = np.random.rand(N, N).astype(np.float32)
B = np.random.rand(N, N).astype(np.float32)
C = np.zeros((N, N), dtype=np.float32)

# Копируем данные в GPU
d_A = cuda.to_device(A)
d_B = cuda.to_device(B)
d_C = cuda.to_device(C)

# Определяем размер блоков и сетки
threads_per_block = (16, 16)
blocks_per_grid = ((N + 15) // 16, (N + 15) // 16)

# ⏳ Замер времени выполнения
start_cpu = time.time()

# Запуск ядра на GPU
matrix_mul[blocks_per_grid, threads_per_block](d_A, d_B, d_C)

# Синхронизация для точного замера
cuda.synchronize()

end_cpu = time.time()

# Копируем результат обратно
C = d_C.copy_to_host()

gpu_time = (end_cpu - start_cpu) * 1000  # Время на GPU (в миллисекундах)

print(f"Время выполнения на GPU (Numba): {gpu_time:.2f} ms")

