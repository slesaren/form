# CUDA (PyCUDA)

import pycuda.driver as cuda
import pycuda.autoinit  # Инициализация CUDA-контекста
import numpy as np
from pycuda.compiler import SourceModule
import time

# CUDA-ядро для умножения матриц
cuda_code = """
__global__ void matrix_mul(float *A, float *B, float *C, int N) {
    int row = blockIdx.y * blockDim.y + threadIdx.y;
    int col = blockIdx.x * blockDim.x + threadIdx.x;

    if (row < N && col < N) {
        float sum = 0.0;
        for (int k = 0; k < N; k++) {
            sum += A[row * N + k] * B[k * N + col];
        }
        C[row * N + col] = sum;
    }
}
"""

# Указываем архитектуру для вашей GTX 1650 (см_75)
mod = SourceModule(cuda_code, options=["-arch=sm_75"])
matrix_mul = mod.get_function("matrix_mul")

# Размер матриц
N = 512
A = np.random.rand(N, N).astype(np.float32)
B = np.random.rand(N, N).astype(np.float32)
C = np.zeros((N, N), dtype=np.float32)

# Копируем данные в GPU
d_A = cuda.mem_alloc(A.nbytes)
d_B = cuda.mem_alloc(B.nbytes)
d_C = cuda.mem_alloc(C.nbytes)

cuda.memcpy_htod(d_A, A)
cuda.memcpy_htod(d_B, B)

# Размер блоков и сетки
block_size = (16, 16, 1)
grid_size = (N // 16, N // 16, 1)

# Измеряем время
start_time = time.time()
matrix_mul(d_A, d_B, d_C, np.int32(N), block=block_size, grid=grid_size)
cuda.Context.synchronize()
end_time = time.time()

# Копируем результат обратно
cuda.memcpy_dtoh(C, d_C)

print(f"Время выполнения на GPU (PyCUDA): {(end_time - start_time) * 1000:.2f} ms")
